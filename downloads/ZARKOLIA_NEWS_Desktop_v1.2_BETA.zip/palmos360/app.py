"""ZARKOLIA NEWS Desktop v1.2. Local-only dashboard and incremental RSS archive."""
import html
import json
import os
import re
import threading
import time
import urllib.parse
import urllib.request
import webbrowser
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from email.utils import parsedate_to_datetime
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from xml.etree import ElementTree as ET

BASE = Path(__file__).resolve().parent
SOURCES = json.loads((BASE / 'sources.json').read_text(encoding='utf-8'))
DATA = Path(os.environ.get('LOCALAPPDATA') or Path.home() / '.local' / 'share') / 'Palmos360'
DATA.mkdir(parents=True, exist_ok=True)
STATE_FILE = DATA / 'clippings.json' # compatible with v0.5
state_lock = threading.RLock()
refresh_lock = threading.Lock()
cache = {'articles': [], 'sources': [], 'updated': 0, 'refreshing': False}

try:
    state = json.loads(STATE_FILE.read_text(encoding='utf-8'))
    if not isinstance(state, dict):
        raise ValueError('Invalid state')
except (OSError, ValueError):
    state = {'archive': [], 'keywords': []}
state.setdefault('archive', [])
state.setdefault('keywords', [])

# On first launch, recover the last collected articles from the v0.5 archive.
cache['articles'] = sorted((a for a in state['archive'] if isinstance(a, dict)), key=lambda a: a.get('date', 0), reverse=True)[:500]


def persist():
    temp = STATE_FILE.with_suffix('.tmp')
    temp.write_text(json.dumps(state, ensure_ascii=False), encoding='utf-8')
    temp.replace(STATE_FILE)


def plain(value):
    value = re.sub(r'<[^>]*>', ' ', value or '')
    return re.sub(r'\s+', ' ', html.unescape(value)).strip()


def classify(title, category):
    """Only classify generic feeds. The dedicated topic feed owns its assigned topic."""
    if category not in ('Επικαιρότητα', 'Ελλάδα'):
        return category
    t = plain(title).casefold()
    patterns = (
        ('Αθλητικά', r'ποδόσφαιρ|μπάσκετ|ολυμπιακ|παναθηναϊκ|αεκ|παοκ|αθλητ|champions league|super league|εθνική ομάδα'),
        ('Οικονομία', r'οικονομί|πληθωρισμ|χρηματιστήρι|τράπεζ|επιτόκι|επενδύσ|φορολογ|αεκπ|μισθ|συνταξιοδοτ'),
        ('Πολιτική', r'κυβέρνησ|βουλή|υπουργ|πρωθυπουργ|εκλογ|κόμμα|βουλευτ|πασοκ|νέα δημοκρατία|συριζα'),
        ('Υγεία', r'υγεία|εμβόλι|νοσοκομ|ιατρ|φαρμακ|ασθεν|θεραπεία'),
        ('Τεχνολογία', r'τεχνολογ|τεχνητή νοημοσύνη|κυβερνοασφάλ|λογισμικ|smartphone'),
        ('Διεθνή', r'ηπα|ουκρανί|ρωσί|ευρωπαϊκή ένωση|ντόναλντ τραμπ|ισραήλ|μέση ανατολή'),
    )
    for name, pattern in patterns:
        if re.search(pattern, t):
            return name
    return 'Κοινωνία' if category == 'Ελλάδα' else 'Επικαιρότητα'


def date_stamp(value):
    try:
        return parsedate_to_datetime(value).timestamp()
    except Exception:
        try:
            return datetime.fromisoformat(value.replace('Z', '+00:00')).timestamp()
        except Exception:
            return 0


def fetch(source):
    try:
        request = urllib.request.Request(source['url'], headers={
            'User-Agent': 'Mozilla/5.0 (compatible; Palmos360Desktop/1.0; RSS reader)',
            'Accept': 'application/rss+xml,application/atom+xml,application/xml,text/xml,*/*'
        })
        with urllib.request.urlopen(request, timeout=12) as response:
            data = response.read(3_000_000)
        root = ET.fromstring(data)
        items = []
        for item in root.iter():
            if item.tag.rsplit('}', 1)[-1] not in ('item', 'entry'):
                continue
            def get(*names):
                for element in item:
                    if element.tag.rsplit('}', 1)[-1] in names:
                        return element.attrib.get('href') or ''.join(element.itertext())
                return ''
            title = plain(get('title'))
            link = get('link').strip()
            if not title or urllib.parse.urlparse(link).scheme not in ('http', 'https'):
                continue
            items.append({
                'title': title,
                'link': link,
                'source': source['name'],
                'category': classify(title, source['category']),
                'date': date_stamp(get('pubDate', 'published', 'updated', 'date')),
                'summary': plain(get('description', 'summary', 'content'))[:240],
            })
            if len(items) >= 40:
                break
        return items, {'name': source['name'], 'ok': bool(items), 'count': len(items),
                       **({'error': 'Δεν βρέθηκαν άρθρα στη ροή'} if not items else {})}
    except Exception as exc:
        return [], {'name': source['name'], 'ok': False, 'count': 0, 'error': f'{type(exc).__name__}: {str(exc)[:125]}'}


def refresh_worker():
    if not refresh_lock.acquire(blocking=False):
        return
    with state_lock:
        cache['refreshing'] = True
    try:
        with ThreadPoolExecutor(max_workers=10) as pool:
            results = list(pool.map(fetch, SOURCES))
        fresh = {}
        for entries, _ in results:
            for entry in entries:
                old = fresh.get(entry['link'])
                # Prefer the explicit specialised category over a generic front page.
                if old is None or (old['category'] == 'Επικαιρότητα' and entry['category'] != 'Επικαιρότητα'):
                    fresh[entry['link']] = entry
        with state_lock:
            cutoff = time.time() - 30 * 86400
            historical = {a['link']: a for a in state['archive']
                          if isinstance(a, dict) and a.get('link') and a.get('collected', 0) >= cutoff}
            now = time.time()
            for link, article in fresh.items():
                previous = historical.get(link)
                historical[link] = dict(article, collected=(previous or {}).get('collected', now))
            state['archive'] = sorted(historical.values(), key=lambda a: a.get('collected', 0), reverse=True)[:15000]
            persist()
            # Show the newest available articles even if individual feeds are unavailable.
            cache['articles'] = sorted(state['archive'], key=lambda a: a.get('date', 0), reverse=True)[:800]
            cache['sources'] = [source_status for _, source_status in results]
            cache['updated'] = time.time()
    finally:
        with state_lock:
            cache['refreshing'] = False
        refresh_lock.release()


def start_refresh(force=False):
    with state_lock:
        if cache['refreshing'] or (not force and time.time()-cache['updated'] < 600):
            return False
        cache['refreshing'] = True
    t = threading.Thread(target=refresh_worker, daemon=True)
    try:
        t.start()
    except Exception:
        with state_lock:
            cache['refreshing'] = False
        raise
    return True


def payload():
    start_refresh()
    with state_lock:
        return {**cache, 'archive': sorted(state['archive'], key=lambda a:a.get('date',0), reverse=True),
                'keywords': list(state['keywords'])}


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(BASE), **kwargs)

    def log_message(self, fmt, *args):
        if self.path not in ('/api/news', '/api/status'):
            super().log_message(fmt, *args)

    def send_json(self, data):
        raw = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        if path == '/api/news':
            self.send_json(payload())
        elif path == '/api/status':
            with state_lock:
                self.send_json({k: cache[k] for k in ('updated', 'refreshing', 'sources')})
        else:
            super().do_GET()

    def do_POST(self):
        if self.path not in ('/api/keywords', '/api/refresh'):
            self.send_error(404)
            return
        expected = f'http://127.0.0.1:{self.server.server_address[1]}'
        if self.headers.get('Origin') != expected:
            self.send_error(403)
            return
        if self.path == '/api/refresh':
            start_refresh(force=True)
            self.send_json({'refreshing': True})
            return
        if self.headers.get('Content-Type') != 'application/json':
            self.send_error(403)
            return
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if not 0 < size <= 16000:
                raise ValueError('invalid request size')
            values = json.loads(self.rfile.read(size))
            if (not isinstance(values, list) or len(values) > 100 or
                any(not isinstance(v, str) or not 0 < len(v.strip()) <= 300 for v in values)):
                raise ValueError('invalid keywords')
            with state_lock:
                state['keywords'] = list(dict.fromkeys(v.strip() for v in values))
                persist()
                self.send_json(state['keywords'])
        except (ValueError, OSError):
            self.send_error(400)


if __name__ == '__main__':
    server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    address = f'http://127.0.0.1:{server.server_address[1]}/'
    print('ZARKOLIA NEWS Desktop v1.2:', address, flush=True)
    start_refresh(force=True)
    timer = threading.Timer(1, lambda: webbrowser.open(address))
    timer.daemon = True
    timer.start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()