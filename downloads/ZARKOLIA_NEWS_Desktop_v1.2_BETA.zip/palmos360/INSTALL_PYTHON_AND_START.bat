@echo off
setlocal
cd /d "%~dp0"
echo ZARKOLIA NEWS Desktop - optional Python installer
py -3 --version >nul 2>nul
if not errorlevel 1 goto START
python --version >nul 2>nul
if not errorlevel 1 goto START
if exist "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" goto START
where winget >nul 2>nul
if errorlevel 1 goto MANUAL
echo.
echo This step downloads Python 3.13 from the winget repository.
echo Read prompts from Windows before approving installation.
choice /C YN /M "Install Python 3.13 and run ZARKOLIA NEWS"
if errorlevel 2 exit /b 0
winget install --id Python.Python.3.13 -e --source winget --accept-package-agreements --accept-source-agreements
if errorlevel 1 goto MANUAL
:START
call START.bat
exit /b %errorlevel%
:MANUAL
echo Please install Python 3.13 from https://www.python.org/downloads/windows/
pause
exit /b 1