@echo off
setlocal
cd /d "%~dp0"
py -3 --version >nul 2>nul
if not errorlevel 1 goto RUN_PY
python --version >nul 2>nul
if not errorlevel 1 goto RUN_PYTHON
if exist "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" goto RUN_LOCAL
if exist "%ProgramFiles%\Python313\python.exe" goto RUN_PROGRAM
cls
echo ZARKOLIA NEWS requires Python 3.10 or newer.
echo Python was not found on this PC.
echo Run INSTALL_PYTHON_AND_START.bat or install Python from python.org.
pause
exit /b 1
:RUN_PY
py -3 app.py
goto FINISH
:RUN_PYTHON
python app.py
goto FINISH
:RUN_LOCAL
"%LOCALAPPDATA%\Programs\Python\Python313\python.exe" app.py
goto FINISH
:RUN_PROGRAM
"%ProgramFiles%\Python313\python.exe" app.py
:FINISH
if errorlevel 1 echo ZARKOLIA NEWS stopped with an error.
pause