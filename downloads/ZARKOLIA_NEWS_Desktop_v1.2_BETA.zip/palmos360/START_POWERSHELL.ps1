$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$py = Get-Command py -ErrorAction SilentlyContinue
if ($py) {
    & py -3 app.py
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    & python app.py
} else {
    Write-Host 'Python 3.10+ required: https://www.python.org/downloads/windows/'
}
Read-Host 'Press Enter to close'